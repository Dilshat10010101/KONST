window.onload = (event) => {
    if (sessionStorage.saveBackgroundColor != "") {
        document.body.classList.toggle(sessionStorage.saveBackgroundColor);
    }
    if (sessionStorage.saveTextColor != "") {
        document.body.classList.toggle(sessionStorage.saveTextColor);
    }
    if (sessionStorage.saveFont != "") {
        document.body.classList.toggle(sessionStorage.saveFont);
    }
    if (sessionStorage.saveDarkmode != "") {
        document.body.classList.toggle(sessionStorage.saveDarkmode);
        document.getElementsByClassName("Menu")[0].classList.toggle("dark-mode-nav");  
    }
    if (sessionStorage.saveColor !=""){
        document.body.classList.toggle(sessionStorage.saveColor);
    }


    console.log(sessionStorage.saveBackgroundColor); // Sparar bakgrundsfärgen
    console.log(sessionStorage.saveTextColor); // Sparar textfärgen
    console.log(sessionStorage.saveFont); // Sparar typsnittet
    console.log(sessionStorage.saveDarkmode); // Sparar Darkmode/Lightmode
    console.log(sessionStorage.saveColor);
}

function Toggle()
{
    var knapp = document.getElementById("toggle");

    document.body.classList.toggle("dark-mode");
    
    tooglesaveddarkmode("dark-mode");

    var menu = document.getElementsByClassName("Menu");
    
    console.log(menu);

    menu[0].classList.toggle("dark-mode-nav");

    if("Dark mode off"==knapp.textContent)
    
    {

        knapp.textContent =  "Dark mode on";

    }
    else
    {
        knapp.textContent =  "Dark mode off";

    }

}


function ClosePopUpp() {
    const closebutton = document.getElementById("PopUpp").style.display = "none";
}
function GetInfoBoxFont() {
    const informationdiv = document.getElementsByClassName("PopUpp");
    document.getElementById("PopUpp").style.display = "block"
}

function ClosePopUpp1() {
    const closebutton1 = document.getElementById("PopUpp1").style.display = "none";
}
function GetChangeBackgroundColor() {
    const informationdiv1 = document.getElementsByClassName("PopUpp1");
    document.getElementById("PopUpp1").style.display = "block"
}

function ClosePopUpp2() {
    const closebutton2 = document.getElementById("PopUpp2").style.display = "none";
}
function GetChangeTextColor() {
    const informationdiv2 = document.getElementsByClassName("PopUpp2");
    document.getElementById("PopUpp2").style.display = "block"
}



function Arialbutton(){
    document.body.classList.toggle("arialtext");
    tooglesavedfont("arialtext");
}
function Georigabutton(){
    document.body.classList.toggle("georigatext");
    tooglesavedfont("georgiatext");
}
function Franklinbutton(){
    document.body.classList.toggle("franklintext");
    tooglesavedfont("franklintext");
}


function BlueButton(){
    document.body.classList.toggle("bluebackground");
    tooglesavedbackground("bluebackground");
}
function RedButton(){
    document.body.classList.toggle("redbackground");
    tooglesavedbackground("redbackground");
}
function YellowButton(){
    document.body.classList.toggle("yellowbackground");
    tooglesavedbackground("yellowbackground");
}

function BlueTextButton(){
    document.body.classList.toggle("bluetext");
    tooglesavedbackground("bluetext");
}
function RedTextButton(){
    document.body.classList.toggle("redtext");
    tooglesavedbackground("redtext");
}
function YellowTextButton(){
    document.body.classList.toggle("yellowtext");
    tooglesavedbackground("yellowtext");
}


function tooglesavedbackground(color) {
    tempColor = color;
    if (color == sessionStorage.saveBackgroundColor) {
        sessionStorage.saveBackgroundColor = "";
    }
    else {
        sessionStorage.saveBackgroundColor = tempColor;
    }
}
function tooglesavedtext(color) {
    temptextColor = color;
    if (color == sessionStorage.saveTextColor) {
        sessionStorage.saveTextColor = "";
    }
    else {
        sessionStorage.saveTextColor = temptextColor;
    }
}

function tooglesaveddarkmode(color) {
    tempdarkmodeColor = color;
    if (color == sessionStorage.saveDarkmode) {
        sessionStorage.saveDarkmode = "";
    }
    else {
        sessionStorage.saveDarkmode = tempdarkmodeColor;
    }
}

function tooglesavedfont(font) {
    tempsavedfont = font;
    if (font == sessionStorage.saveFont) {
        sessionStorage.saveFont = "";
    }
    else {
        sessionStorage.saveFont = tempsavedfont;
    }

    function tooglesavedtextcolor(color) {
        tempsavedfont = color;
        if (color == sessionStorage.saveColor) {
            sessionStorage.saveColor = "";
        }
        else {
            sessionStorage.saveColor = tempsavedcolor;
        }
    }
}

